package com.piphorror.mod.entity;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.Comparator;
import java.util.List;
import java.util.UUID;

public class PipEntity extends PathfinderMob implements GeoEntity {
    public static final String STATE_STALK = "idle_stalk";
    public static final String STATE_LOOKOUT_LISTEN = "lookout_listen";
    public static final String STATE_PROWL_WALK = "prowl_walk";
    public static final String STATE_PEEK = "peek_corner";
    public static final String STATE_HUNT = "crawl_hunt";
    public static final String STATE_FAKE_IGNORE = "fake_ignore_stare";
    public static final String STATE_SUMMON = "event_summon";

    private static final String TASK_NONE = "";
    private static final String TASK_GATHER_WOOD = "GATHER_WOOD";
    private static final String TASK_FETCH_ITEM = "FETCH_ITEM";

    private static final EntityDataAccessor<String> AI_STATE =
        SynchedEntityData.defineId(PipEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Boolean> IS_FAKE_PIP =
        SynchedEntityData.defineId(PipEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> LISTEN_TICKS =
        SynchedEntityData.defineId(PipEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> EVENT_TICKS =
        SynchedEntityData.defineId(PipEntity.class, EntityDataSerializers.INT);

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);
    private UUID listeningTargetUuid;

    // Active autonomous companion task state (Gather Wood / Fetch Item)
    private String activeTask = TASK_NONE;
    private UUID taskOwnerUuid;
    private BlockPos taskTargetPos;
    private int taskPhase = 0; // 0=heading out, 1=harvesting/searching, 2=returning to player
    private int taskTicks = 0;
    private int temporaryMonsterTicks = 0;
    private ItemStack carriedStack = ItemStack.EMPTY;
    private Item requestedFetchItem = Items.AIR;
    private int requestedFetchCount = 1;

    private static final RawAnimation ANIM_LOOKOUT_LISTEN =
        RawAnimation.begin().thenLoop("animation.pip.lookout_listen");
    private static final RawAnimation ANIM_IDLE_STALK =
        RawAnimation.begin().thenLoop("animation.pip.idle_stalk");
    private static final RawAnimation ANIM_PROWL_WALK =
        RawAnimation.begin().thenLoop("animation.pip.prowl_walk");
    private static final RawAnimation ANIM_PEEK_CORNER =
        RawAnimation.begin().thenLoop("animation.pip.peek_corner");
    private static final RawAnimation ANIM_CRAWL_HUNT =
        RawAnimation.begin().thenLoop("animation.pip.crawl_hunt");
    private static final RawAnimation ANIM_FAKE_IGNORE =
        RawAnimation.begin().thenLoop("animation.pip.fake_ignore_stare");
    private static final RawAnimation ANIM_EVENT_SUMMON =
        RawAnimation.begin().thenPlay("animation.pip.event_summon");

    public PipEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, 80.0D)
            .add(Attributes.MOVEMENT_SPEED, 0.34D)
            .add(Attributes.ATTACK_DAMAGE, 7.0D)
            .add(Attributes.FOLLOW_RANGE, 64.0D);
    }

    public static boolean canSpawnInWorld(
        EntityType<? extends PathfinderMob> type,
        LevelAccessor level,
        MobSpawnType reason,
        BlockPos pos,
        RandomSource random
    ) {
        if (!Mob.checkMobSpawnRules(type, level, reason, pos, random)) {
            return false;
        }
        int nearby = level.getEntitiesOfClass(PipEntity.class, new AABB(pos).inflate(112.0D)).size();
        return nearby < 3;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(AI_STATE, STATE_STALK);
        this.entityData.define(IS_FAKE_PIP, false);
        this.entityData.define(LISTEN_TICKS, 0);
        this.entityData.define(EVENT_TICKS, 0);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (IS_FAKE_PIP.equals(key)) {
            this.refreshDimensions();
        }
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return isFakePip()
            ? EntityDimensions.scalable(0.85F, 2.85F)
            : EntityDimensions.scalable(0.75F, 1.30F);
    }

    @Override
    protected float getStandingEyeHeight(Pose pose, EntityDimensions dimensions) {
        return dimensions.height * 0.85F;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("IsFakePip", isFakePip());
        tag.putString("AiState", getAiState());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("IsFakePip")) {
            setFakePip(tag.getBoolean("IsFakePip"));
        }
        if (tag.contains("AiState")) {
            setAiState(tag.getString("AiState"));
        }
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 24.0F) {
            @Override
            public boolean canUse() {
                return !hasActiveTask() && super.canUse();
            }
        });
        this.goalSelector.addGoal(5, new RandomStrollGoal(this, 0.65D) {
            @Override
            public boolean canUse() {
                return !isListening() && !hasActiveTask() && !STATE_PEEK.equals(getAiState()) && super.canUse();
            }
        });
    }

    public String getAiState() {
        return this.entityData.get(AI_STATE);
    }

    public void setAiState(String state) {
        this.entityData.set(AI_STATE, state);
    }

    public boolean isFakePip() {
        return this.entityData.get(IS_FAKE_PIP);
    }

    public void setFakePip(boolean fake) {
        this.entityData.set(IS_FAKE_PIP, fake);
        this.refreshDimensions();
    }

    public void revealMonsterBriefly(int ticks) {
        this.temporaryMonsterTicks = Math.max(this.temporaryMonsterTicks, ticks);
        this.setFakePip(true);
    }

    public boolean isListening() {
        return !isFakePip() && (this.entityData.get(LISTEN_TICKS) > 0 || STATE_LOOKOUT_LISTEN.equals(getAiState()));
    }

    public boolean hasActiveTask() {
        return !TASK_NONE.equals(this.activeTask);
    }

    /**
     * Original Pip lowers into its 4-limb stance and raises its front-right paw beside its ear.
     * Tall White Monster Pip refuses to listen and tilts its head sideways with a hollow stare.
     */
    public boolean startLookoutListen(ServerPlayer speaker, int ticks) {
        this.getNavigation().stop();
        if (speaker != null) {
            this.getLookControl().setLookAt(speaker, 45.0F, 45.0F);
        }

        if (this.isFakePip()) {
            this.entityData.set(LISTEN_TICKS, 0);
            this.entityData.set(EVENT_TICKS, ticks);
            this.setAiState(STATE_FAKE_IGNORE);
            this.playSound(SoundEvents.ENDERMAN_STARE, 0.9F, 0.52F);
            return false;
        }

        this.listeningTargetUuid = speaker != null ? speaker.getUUID() : null;
        this.entityData.set(LISTEN_TICKS, ticks);
        this.setAiState(STATE_LOOKOUT_LISTEN);
        this.playSound(SoundEvents.CAT_AMBIENT, 0.75F, 0.85F);
        return true;
    }

    public void startGatherWoodTask(ServerPlayer owner) {
        if (!(this.level() instanceof ServerLevel serverLevel) || owner == null) return;
        this.activeTask = TASK_GATHER_WOOD;
        this.taskOwnerUuid = owner.getUUID();
        this.taskPhase = 0;
        this.taskTicks = 0;
        this.carriedStack = ItemStack.EMPTY;
        this.entityData.set(LISTEN_TICKS, 0);
        this.entityData.set(EVENT_TICKS, 0);
        this.setAiState(STATE_PROWL_WALK);

        BlockPos treePos = findNearestLogPos(serverLevel, this.blockPosition(), 46);
        if (treePos != null) {
            this.taskTargetPos = treePos;
        } else {
            // No nearby forest: venture 22 blocks out to forage & bring logs back
            double angle = this.random.nextDouble() * Math.PI * 2.0D;
            int tx = this.blockPosition().getX() + (int) Math.round(Math.cos(angle) * 22.0D);
            int tz = this.blockPosition().getZ() + (int) Math.round(Math.sin(angle) * 22.0D);
            int ty = serverLevel.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, tx, tz);
            this.taskTargetPos = new BlockPos(tx, ty, tz);
        }
        owner.sendSystemMessage(Component.literal("§a[Pip] §7*twitches ear and sprints off to gather wood!*"));
    }

    public void startFetchItemTask(ServerPlayer owner, Item item, int count) {
        if (!(this.level() instanceof ServerLevel serverLevel) || owner == null || item == null || item == Items.AIR) return;
        this.activeTask = TASK_FETCH_ITEM;
        this.taskOwnerUuid = owner.getUUID();
        this.requestedFetchItem = item;
        this.requestedFetchCount = Math.max(1, count);
        this.carriedStack = ItemStack.EMPTY;
        this.taskPhase = 0;
        this.taskTicks = 0;
        this.entityData.set(LISTEN_TICKS, 0);
        this.entityData.set(EVENT_TICKS, 0);
        this.setAiState(STATE_PROWL_WALK);

        // First check if that item is already dropped nearby in the world
        List<ItemEntity> dropped = serverLevel.getEntitiesOfClass(
            ItemEntity.class,
            this.getBoundingBox().inflate(48.0D),
            e -> e.isAlive() && e.getItem().is(item)
        );
        if (!dropped.isEmpty()) {
            ItemEntity nearest = dropped.stream()
                .min(Comparator.comparingDouble(e -> e.distanceToSqr(this)))
                .orElse(null);
            this.taskTargetPos = nearest != null ? nearest.blockPosition() : this.blockPosition();
        } else {
            double angle = this.random.nextDouble() * Math.PI * 2.0D;
            int tx = this.blockPosition().getX() + (int) Math.round(Math.cos(angle) * 18.0D);
            int tz = this.blockPosition().getZ() + (int) Math.round(Math.sin(angle) * 18.0D);
            int ty = serverLevel.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, tx, tz);
            this.taskTargetPos = new BlockPos(tx, ty, tz);
        }
        String label = new ItemStack(item).getHoverName().getString();
        owner.sendSystemMessage(Component.literal("§a[Pip] §7*runs off to fetch §e" + label + "§7...*"));
    }

    public void triggerTimedState(String state, int ticks) {
        this.entityData.set(LISTEN_TICKS, 0);
        this.entityData.set(EVENT_TICKS, ticks);
        this.setAiState(state);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }

        if (this.temporaryMonsterTicks > 0) {
            this.temporaryMonsterTicks--;
            if (this.temporaryMonsterTicks <= 0 && !hasActiveTask()) {
                this.setFakePip(false);
            }
        }

        if (hasActiveTask() && this.level() instanceof ServerLevel serverLevel) {
            tickAutonomousTask(serverLevel);
            return;
        }

        int listenTicks = this.entityData.get(LISTEN_TICKS);
        if (listenTicks > 0) {
            this.getNavigation().stop();
            if (this.listeningTargetUuid != null) {
                Player speaker = this.level().getPlayerByUUID(this.listeningTargetUuid);
                if (speaker != null) {
                    this.getLookControl().setLookAt(speaker, 35.0F, 35.0F);
                }
            }
            this.entityData.set(LISTEN_TICKS, listenTicks - 1);
            if (listenTicks - 1 <= 0 && STATE_LOOKOUT_LISTEN.equals(getAiState())) {
                this.setAiState(STATE_STALK);
                this.listeningTargetUuid = null;
            }
        }

        int eventTicks = this.entityData.get(EVENT_TICKS);
        if (eventTicks > 0) {
            this.entityData.set(EVENT_TICKS, eventTicks - 1);
            if (eventTicks - 1 <= 0 && !isListening()) {
                this.setAiState(STATE_STALK);
            }
        }
    }

    private void tickAutonomousTask(ServerLevel level) {
        this.taskTicks++;
        Player owner = this.taskOwnerUuid != null ? level.getPlayerByUUID(this.taskOwnerUuid) : null;
        if (owner == null) {
            clearTask();
            return;
        }

        if (this.taskPhase == 0) {
            this.setAiState(STATE_PROWL_WALK);
            if (this.taskTargetPos != null) {
                this.getNavigation().moveTo(
                    this.taskTargetPos.getX() + 0.5D,
                    this.taskTargetPos.getY(),
                    this.taskTargetPos.getZ() + 0.5D,
                    1.32D
                );
                double distSq = this.distanceToSqr(
                    this.taskTargetPos.getX() + 0.5D,
                    this.taskTargetPos.getY(),
                    this.taskTargetPos.getZ() + 0.5D
                );
                if (distSq <= 10.5D || this.taskTicks >= 110) {
                    this.getNavigation().stop();
                    this.taskPhase = 1;
                    this.taskTicks = 0;
                }
            } else {
                this.taskPhase = 1;
                this.taskTicks = 0;
            }
        } else if (this.taskPhase == 1) {
            this.setAiState(STATE_SUMMON);
            if (this.taskTicks == 15) {
                if (TASK_GATHER_WOOD.equals(this.activeTask)) {
                    this.carriedStack = harvestWoodBundle(level);
                    level.playSound(null, this.blockPosition(), SoundEvents.WOOD_BREAK, SoundSource.NEUTRAL, 1.0F, 1.0F);
                } else if (TASK_FETCH_ITEM.equals(this.activeTask)) {
                    this.carriedStack = collectOrCreateFetchedStack(level);
                    level.playSound(null, this.blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.NEUTRAL, 0.85F, 1.2F);
                }
                level.sendParticles(ParticleTypes.HAPPY_VILLAGER, this.getX(), this.getY() + 1.0D, this.getZ(), 8, 0.3D, 0.3D, 0.3D, 0.02D);
            }
            if (this.taskTicks >= 32) {
                this.taskPhase = 2;
                this.taskTicks = 0;
            }
        } else {
            // Returning to player
            this.setAiState(STATE_PROWL_WALK);
            this.getNavigation().moveTo(owner, 1.38D);

            if (this.taskTicks == 180 && this.distanceToSqr(owner) > 36.0D) {
                // Pathfinding assist if Pip got stuck behind terrain while returning
                Vec3 back = owner.position().add(owner.getLookAngle().scale(3.2D));
                int surfaceY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) back.x, (int) back.z);
                this.teleportTo(back.x, surfaceY, back.z);
            }

            if (this.distanceToSqr(owner) <= 8.5D || this.taskTicks >= 220) {
                this.getNavigation().stop();
                this.getLookControl().setLookAt(owner, 45.0F, 45.0F);
                deliverCarriedItem(level, owner);
                clearTask();
            }
        }
    }

    private ItemStack harvestWoodBundle(ServerLevel level) {
        Item logItem = Items.OAK_LOG;
        int broken = 0;
        BlockPos origin = this.blockPosition();
        for (BlockPos p : BlockPos.betweenClosed(origin.offset(-5, -2, -5), origin.offset(5, 8, 5))) {
            BlockState st = level.getBlockState(p);
            if (st.is(BlockTags.LOGS)) {
                Item blockItem = st.getBlock().asItem();
                if (blockItem != Items.AIR) {
                    logItem = blockItem;
                }
                level.destroyBlock(p, false);
                broken++;
                if (broken >= 6) break;
            }
        }
        int amount = Math.max(16, Math.min(32, 16 + broken * 3));
        return new ItemStack(logItem, amount);
    }

    private ItemStack collectOrCreateFetchedStack(ServerLevel level) {
        List<ItemEntity> matches = level.getEntitiesOfClass(
            ItemEntity.class,
            this.getBoundingBox().inflate(8.0D),
            e -> e.isAlive() && e.getItem().is(this.requestedFetchItem)
        );
        if (!matches.isEmpty()) {
            ItemEntity picked = matches.get(0);
            ItemStack copy = picked.getItem().copy();
            picked.discard();
            return copy;
        }
        int clamped = Math.min(this.requestedFetchCount, Math.max(1, this.requestedFetchItem.getMaxStackSize()));
        return new ItemStack(this.requestedFetchItem, clamped);
    }

    private void deliverCarriedItem(ServerLevel level, Player owner) {
        if (this.carriedStack.isEmpty()) {
            return;
        }
        Vec3 dropPos = owner.position().add(owner.getLookAngle().scale(1.25D));
        ItemEntity drop = new ItemEntity(level, dropPos.x, owner.getY() + 0.35D, dropPos.z, this.carriedStack.copy());
        drop.setNoPickUpDelay();
        level.addFreshEntity(drop);
        this.playSound(SoundEvents.CAT_PURREOW, 0.9F, 1.15F);
        owner.sendSystemMessage(Component.literal(
            "§a[Pip] §fDropped §e" + this.carriedStack.getCount() + "x " + this.carriedStack.getHoverName().getString() + "§f for you!"
        ));
    }

    private void clearTask() {
        this.activeTask = TASK_NONE;
        this.taskOwnerUuid = null;
        this.taskTargetPos = null;
        this.taskPhase = 0;
        this.taskTicks = 0;
        this.carriedStack = ItemStack.EMPTY;
        this.requestedFetchItem = Items.AIR;
        this.setAiState(STATE_STALK);
    }

    private static BlockPos findNearestLogPos(ServerLevel level, BlockPos center, int radius) {
        BlockPos best = null;
        double bestDistSq = Double.MAX_VALUE;
        for (int dx = -radius; dx <= radius; dx += 2) {
            for (int dz = -radius; dz <= radius; dz += 2) {
                int x = center.getX() + dx;
                int z = center.getZ() + dz;
                int topY = level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
                for (int dy = -6; dy <= 4; dy++) {
                    BlockPos p = new BlockPos(x, topY + dy, z);
                    if (level.getBlockState(p).is(BlockTags.LOGS)) {
                        double d = p.distSqr(center);
                        if (d < bestDistSq) {
                            bestDistSq = d;
                            best = p.immutable();
                        }
                        break;
                    }
                }
            }
        }
        return best;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "pip_main_controller", 4, state -> {
            String aiState = getAiState();
            return switch (aiState) {
                case STATE_LOOKOUT_LISTEN -> state.setAndContinue(ANIM_LOOKOUT_LISTEN);
                case STATE_PROWL_WALK -> state.setAndContinue(ANIM_PROWL_WALK);
                case STATE_PEEK -> state.setAndContinue(ANIM_PEEK_CORNER);
                case STATE_HUNT -> state.setAndContinue(ANIM_CRAWL_HUNT);
                case STATE_FAKE_IGNORE -> state.setAndContinue(ANIM_FAKE_IGNORE);
                case STATE_SUMMON -> state.setAndContinue(ANIM_EVENT_SUMMON);
                default -> {
                    if (state.isMoving()) {
                        state.setAndContinue(ANIM_PROWL_WALK);
                    } else {
                        state.setAndContinue(ANIM_IDLE_STALK);
                    }
                    yield PlayState.CONTINUE;
                }
            };
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.geoCache;
    }
}
