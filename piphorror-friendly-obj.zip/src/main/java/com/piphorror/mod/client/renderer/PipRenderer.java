package com.piphorror.mod.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.piphorror.mod.PipHorrorMod;
import com.piphorror.mod.client.model.PipModel;
import com.piphorror.mod.client.model.PipObjModel;
import com.piphorror.mod.entity.PipEntity;
import com.piphorror.mod.init.ModEntities;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

import java.util.Map;

@Mod.EventBusSubscriber(modid = PipHorrorMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class PipRenderer extends GeoEntityRenderer<PipEntity> {
    /** The OBJ is ~0.9 blocks tall; this scales it to fill Pip's 0.75 x 1.30 hitbox. Change to resize. */
    private static final float FRIENDLY_SCALE = 1.4F;

    private boolean drawingFriendly = false;

    public PipRenderer(EntityRendererProvider.Context context) {
        super(context, new PipModel());
        this.shadowRadius = 0.55F;
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.PIP.get(), PipRenderer::new);
    }

    @Override
    public void render(PipEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource bufferSource, int packedLight) {
        boolean friendly = !entity.isFakePip();
        this.drawingFriendly = friendly;
        if (friendly) {
            poseStack.pushPose();
            poseStack.scale(FRIENDLY_SCALE, FRIENDLY_SCALE, FRIENDLY_SCALE);
        }
        try {
            super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
        } finally {
            if (friendly) {
                poseStack.popPose();
            }
            this.drawingFriendly = false;
        }
    }

    /**
     * The friendly Pip has no cubes - for each animated bone we draw the OBJ triangles that belong
     * to it, using the bone's current (animated) transform from the pose stack.
     */
    @Override
    public void renderCubesOfBone(PoseStack poseStack, GeoBone bone, VertexConsumer buffer, int packedLight,
                                  int packedOverlay, float red, float green, float blue, float alpha) {
        if (!this.drawingFriendly) {
            super.renderCubesOfBone(poseStack, bone, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            return;
        }
        if (bone.isHidden()) {
            return;
        }

        Map<String, float[]> all = PipObjModel.getQuadsByBone();
        if (all == null) {
            return;
        }
        float[] quads = all.get(bone.getName());
        if (quads == null) {
            return;
        }

        PoseStack.Pose pose = poseStack.last();
        Matrix4f matrix = pose.pose();
        Matrix3f normalMatrix = pose.normal();
        int stride = PipObjModel.FLOATS_PER_VERTEX;
        for (int i = 0; i + stride <= quads.length; i += stride) {
            buffer.vertex(matrix, quads[i], quads[i + 1], quads[i + 2])
                .color(red, green, blue, alpha)
                .uv(quads[i + 3], quads[i + 4])
                .overlayCoords(packedOverlay)
                .uv2(packedLight)
                .normal(normalMatrix, quads[i + 5], quads[i + 6], quads[i + 7])
                .endVertex();
        }
    }
}
