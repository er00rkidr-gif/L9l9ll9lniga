# Pip AI Horror — Forge 1.20.1 Upgrade Guide

## What Was Added / Upgraded
1. **Original Friendly Pip + Tall White Monster Form & Embedded 64x64 PNG Textures**
   - `assets/piphorror/textures/entity/pip_horror.png` — pastel mint-green head, big white/black eyes, pink nose, rosy cheeks, stitched mouth, mint-to-lavender belly.
   - `assets/piphorror/textures/entity/pip_fake.png` — pale bone-white tall gaunt creature (~2.85 blocks tall) with bunny tail, floppy ears, wide staring ringed eyes, and dark hollow mouth.
2. **Automatic World Creation Spawn (`PipWorldSpawner.java` + Overworld Biome Modifier)**
   - Automatically spawns Original Friendly Pip near you when creating/joining a new world—no `/summon` command required.
3. **Working Autonomous Tasks & Cover-Peeking Horror Events**
   - `"pip, gather me some wood"` — Pip sprints out, breaks nearby tree logs (or forages away), and brings back 16–32 logs dropped right at your feet.
   - `"pip, fetch me a <item name>"` — resolves any Minecraft item via `BuiltInRegistries.ITEM`, runs off to collect it, and delivers it to you.
   - `stalk_behind` / `hallucination_decoy` — scans real nearby walls/trees/corners and makes Pip crouch and peek out from behind blocks!
4. **Brigadier Commands (`src/main/java/com/piphorror/mod/command/PipEventsCommand.java`)**
   - `/pip listen [player]`
   - `/pip gather wood`
   - `/pip fetch <item_name>`
   - `/pip variant <real|fake>`
   - `/pip event <lights_flicker|stalk_behind|door_knock|mimic_whisper|hunt_escalation|hallucination_decoy> [player]`

## Friendly Pip now uses the OBJ model (v1.3)
- `assets/piphorror/models/entity/friendly_pip.obj` + `textures/entity/friendly_pip.png` — the new friendly Pip mesh/texture.
- `assets/piphorror/geo/friendly_pip.geo.json` — bone skeleton only (no cubes). GeckoLib animates these bones.
- `assets/piphorror/animations/friendly_pip.animation.json` — the new animations (same animation names as before).
- `PipObjModel.java` loads the OBJ and groups its triangles by bone; `PipRenderer.java` draws them each frame with
  the animated bone transform. The tall white monster Pip still uses its original GeckoLib model/animations.
- Bone mapping: body -> `pelvis`; head/eyes/cheeks/nose/lips/tears -> `head`; arm -> `front_leg_left/right`;
  palm + fingers -> `front_paw_left/right`. Legs, ears, tail and jaw exist as empty bones so animations that
  reference them are harmless.
- Size: change `FRIENDLY_SCALE` in `PipRenderer.java` (default 1.4).
